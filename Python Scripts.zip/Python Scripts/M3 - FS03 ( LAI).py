"""
M3 - FS03
LAI images 
2 LSTM Layers
Dropout 20%
10 folds Cross-Validation 
ResNet50, LSTM

"""
#Libraries

import os
import tifffile
import keras
import openpyxl
import numpy as np
import cv2


from keras.applications.resnet50 import ResNet50, preprocess_input
from keras.layers import GlobalAveragePooling2D
from keras.preprocessing import image
from keras.preprocessing.image import img_to_array


from keras.models import Model
from keras.layers import Reshape
from keras.layers import LSTM, Dropout, Dense, Input

from sklearn.model_selection import KFold
from sklearn.utils import shuffle
#from tensorflow.keras.optimizers import Adam

from sklearn.metrics import r2_score, mean_squared_error
from scipy.stats import pearsonr
import math
import matplotlib.pyplot as plt


#%% Load Labels

workbook = openpyxl.load_workbook('E:\Ph.D\PhD Thesis\Datasets\Crop yield statistics\Yield_Labels.xlsx')
worksheet = workbook['Sheet1']

labels = []
i=0
for row in worksheet.iter_rows(min_row=2, max_row=1145, values_only=True):
    row_values = list(row)[2]
    labels.append(row_values)
    i+=1  

labels = np.array(labels, dtype=float)
print("Number of Labels:", len(labels))


#  load LAI Images

LAI_path = r'E:\Ph.D\PhD Thesis\Datasets\GEE\LAI-TehsilWise-12TimeSteps'   
LAI_list = os.listdir(LAI_path) 

# Filter the list to include only TIFF files
tif_files = [file for file in LAI_list if file.endswith(".tif")]

# Load the TIFF images
LAI_images = []
for file_name in tif_files:
    file_path = os.path.join(LAI_path, file_name)
    image = tifffile.imread(file_path)
    LAI_images.append(image)

print("Number of LAI images loaded:", len(LAI_images));
LAI_list.clear()


#%% ResNet50 model to extract features 

# Load the ResNet50 model
model = ResNet50(weights='imagenet', include_top=False)

# Add a fully connected layer with 1000 neurons
x = model.output
x = GlobalAveragePooling2D()(x)
x = Dense(1000, activation='relu')(x)

# Define a new model with the modified architecture
model = Model(inputs=model.input, outputs=x)

# Define a function to resize and extract features from a list of images
def extract_features(img_paths):  
    features = []
    
    for img_path in img_paths:
        
        img = cv2.resize(img_path, (224, 224))
        
        # Convert the PIL image object to a numpy array
        x = keras.preprocessing.image.img_to_array(img)
                
        # Preprocess the input by subtracting the mean RGB values of the ImageNet dataset
        x = preprocess_input(x)
        # Add a batch dimension to the input
        x = np.expand_dims(x, axis=0)
        # Use the ResNet50 model to extract features from the image
        features.append(model.predict(x, verbose=0))
        
    # Convert the list of features to a numpy array
    features = np.array(features)
    # Flatten the features to a 1D array
    features = features.reshape((len(img_paths), 1000))
    return features


LAI_features = extract_features(LAI_images)
print("Features of LAI images:", len(LAI_features))
LAI_images.clear()


#%%  LSTM Model 
    
# Input layers
LAI_input = Input(shape=(1, 1000))  
          
# Define the LSTM layers for each input
LAI_LSTM = LSTM(64)(LAI_input)
    
# Merge the LSTM layers
dropout = Dropout(0.2)(LAI_LSTM)

reshaped = Reshape((1, 64))(dropout)
merged_LSTM = LSTM(64)(reshaped)

output = Dense(1)(merged_LSTM)

model = Model(inputs=LAI_input, outputs=output)
model.summary()


# Define evaluation metrics

def willmott_index(observed, predicted):
    # Ensure that the observed and predicted lists have the same length
    if len(observed) != len(predicted):
        raise ValueError("Observed and predicted lists must have the same length.")
    
    # Calculate the mean of the observed values
    mean_observed = sum(observed) / len(observed)
    
    # Calculate the numerator and denominator of the index
    numerator = sum(abs(o - p) for o, p in zip(observed, predicted))
    denominator = sum(abs(o - mean_observed) + abs(p - mean_observed) for o, p in zip(observed, predicted))
    
    # Calculate the index
    index = 1 - (numerator / denominator)
    
    return index

def calculate_mape(actual_values, forecasted_values):
    if len(actual_values) != len(forecasted_values):
        raise ValueError("Both lists must have the same length.")
    
    absolute_percentage_errors = [abs((actual - forecast) / actual) for actual, forecast in zip(actual_values, forecasted_values)]
    mean_absolute_percentage_error = (sum(absolute_percentage_errors) / len(actual_values)) * 100
    
    return mean_absolute_percentage_error

def calculate_metrics(observed_values, predicted_values):
    
    r_squared = r2_score(observed_values, predicted_values)
    correlation_coefficient, p_value = pearsonr(observed_values, predicted_values)
    mse = mean_squared_error(observed_values, predicted_values)
    rmse = math.sqrt(mse)
    mae = sum([abs(actual - predicted) for actual, predicted in zip(observed_values, predicted_values)]) / len(observed_values)
    mbe = sum([actual - predicted for actual, predicted in zip(observed_values, predicted_values)]) / len(observed_values)
    mre = sum([abs(actual - predicted) / actual for actual, predicted in zip(observed_values, predicted_values)]) / len(observed_values)
    mape = calculate_mape(observed_values, predicted_values)
    wi = willmott_index(observed_values, predicted_values)
 
    return r_squared, correlation_coefficient, p_value, mse, rmse, mae, mbe, mre, mape, wi


#%% Apply k-fold cross validation, training + Evaluation

k = 10
num_epochs = 100



# Initialize lists for storing metrics
r2_scores = []
r_values = []
d_values = []
rmse_values = []
mae_values = []
mbe_values = []
mre_values = []
percentage_error_values = []


# Initialize arrays for storing actual and predicted values
all_actual_values = np.array([])
all_predicted_values = np.array([])

LAI_features, labels = shuffle(LAI_features, labels, random_state=2)

kf = KFold(n_splits=k, shuffle=True)  
fold = 1

for train_index, test_index in kf.split(labels):
    print()
    print(f"Fold: {fold}")
    fold += 1
    
    # Split the data into train and test sets for the current fold
    train_LAI = [LAI_features[i] for i in train_index]
    train_labels = labels[train_index]
    
    test_LAI = [LAI_features[i] for i in test_index]
    test_labels = labels[test_index]
  
    # Compile the model
    model.compile(optimizer='adam', loss='mean_squared_error')
    
    # Convert the lists of arrays to NumPy arrays
    train_LAI = np.array(train_LAI)
    test_LAI = np.array(test_LAI)
    
    
    # Reshape the inputs
    train_LAI = np.expand_dims(train_LAI, axis=1)
    test_LAI = np.expand_dims(test_LAI, axis=1)
    

    # Train the model and store the history
    history = model.fit(train_LAI, train_labels, batch_size = 32, epochs=num_epochs, verbose=1, validation_data=(test_LAI, test_labels))

#%% Model Validation

# Evaluate the model on the test set
predictions = model.predict(test_LAI)
actual_values = test_labels
predicted_values = predictions.flatten()
       
# Print actual and predicted values
for i in range(len(actual_values)):
    print(f"Actual: {actual_values[i]}, Predicted: {predicted_values[i]}")


# Calculate evaluation metrics
r2, r, p, mse, rmse, mae, mbe, mre, mape, d = calculate_metrics(actual_values, predicted_values)

# Print overall metrics
print(f"R-squared (R2) value: {r2:.4f}")
print(f"Correlation coefficient (R): {r:.4f}")
print(f"P-value: {p:.4f}")
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"Mean Bias Error (MBE): {mbe:.4f}")
print(f"Mean Relative Error (MRE): {mre:.4f}")
print(f"Mean Absolute Percentage Error (MAPE): {mape:.2f}%")
print(f"Willmott's index of agreement (d): {d:.4f}")


plt.scatter(actual_values, predicted_values, facecolors='none', edgecolors='black', label='Data Points')

# Add best fit line
best_fit_coeffs = np.polyfit(actual_values, predicted_values, 1)
best_fit_line = np.polyval(best_fit_coeffs, actual_values)

plt.plot(actual_values, best_fit_line, linestyle='--', color='red', linewidth=0.5, label='Best Fit')
plt.plot(actual_values, actual_values, linestyle='--', color='blue', linewidth=0.5, label='1:1 Line (Identity Line)')

legend = plt.legend(loc='upper left', frameon=True)
legend.get_frame().set_edgecolor('black')
legend.get_frame().set_linewidth(0.5)
legend.get_lines()[1].set_linestyle('-')


plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Scatter Plot for FS03')
plt.grid(True)
plt.show()



# Line chart of Loss vs. epochs
plt.plot(range(1, num_epochs + 1), history.history['loss'])
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Loss vs. Epochs for FS03')
plt.show()